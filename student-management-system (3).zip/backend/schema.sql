-- =====================================================================
-- Northfield Registrar — Student Records
-- MySQL schema for the backend
-- =====================================================================

CREATE DATABASE IF NOT EXISTS northfield_registrar
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE northfield_registrar;

-- ---------------------------------------------------------------------
-- Course fee structure (mirrors the COURSE_FEES object in the frontend)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS courses (
  course_name  VARCHAR(100) PRIMARY KEY,
  annual_fee   DECIMAL(10,2) NOT NULL
);

-- ---------------------------------------------------------------------
-- Students
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS students (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  name          VARCHAR(150) NOT NULL,
  roll          VARCHAR(30)  NOT NULL UNIQUE,
  contact       VARCHAR(30)  NOT NULL,
  course        VARCHAR(100) NOT NULL,
  year          VARCHAR(20)  NOT NULL,
  admitted      DATE         NOT NULL,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (course) REFERENCES courses(course_name)
);

-- ---------------------------------------------------------------------
-- Attendance (one row per student per date; status = present/absent)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS attendance (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  student_id    INT NOT NULL,
  att_date      DATE NOT NULL,
  status        ENUM('present','absent') NOT NULL,
  UNIQUE KEY uniq_student_date (student_id, att_date),
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
);

-- ---------------------------------------------------------------------
-- Marks (subject-wise scores per student)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS marks (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  student_id    INT NOT NULL,
  subject       VARCHAR(150) NOT NULL,
  score         DECIMAL(5,2) NOT NULL CHECK (score >= 0 AND score <= 100),
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
);

-- ---------------------------------------------------------------------
-- Payments (fee ledger entries)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS payments (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  student_id    INT NOT NULL,
  amount        DECIMAL(10,2) NOT NULL,
  mode          ENUM('UPI','Card','Bank Transfer','Cash') NOT NULL,
  pay_date      DATE NOT NULL,
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
);

-- =====================================================================
-- Seed data — same values used in the frontend's in-memory demo state
-- =====================================================================

INSERT INTO courses (course_name, annual_fee) VALUES
  ('B.Sc Computer Science', 42000),
  ('B.Com General',          28000),
  ('BA English Literature',  24000),
  ('B.Sc Mathematics',       30000)
ON DUPLICATE KEY UPDATE annual_fee = VALUES(annual_fee);

INSERT INTO students (name, roll, contact, course, year, admitted) VALUES
  ('Meera Raghunathan', 'NF25-014', '98450 11223', 'B.Sc Computer Science', '2nd Year', '2025-06-12'),
  ('Arjun Kadam',        'NF25-021', '99225 44110', 'B.Com General',         '2nd Year', '2025-06-14'),
  ('Fatima Sheikh',      'NF24-089', '90210 33221', 'BA English Literature', '3rd Year', '2024-06-20'),
  ('Rohan Das',          'NF26-005', '98111 22334', 'B.Sc Mathematics',      '1st Year', '2026-06-18')
ON DUPLICATE KEY UPDATE contact = VALUES(contact);

INSERT INTO attendance (student_id, att_date, status) VALUES
  (1, '2026-06-25', 'present'),
  (1, '2026-06-26', 'present'),
  (1, '2026-06-27', 'absent'),
  (2, '2026-06-25', 'present'),
  (2, '2026-06-26', 'absent'),
  (3, '2026-06-25', 'present'),
  (3, '2026-06-26', 'present'),
  (3, '2026-06-27', 'present')
ON DUPLICATE KEY UPDATE status = VALUES(status);

INSERT INTO marks (student_id, subject, score) VALUES
  (1, 'Data Structures',      82),
  (1, 'Discrete Math',        74),
  (2, 'Financial Accounting', 68),
  (3, 'Victorian Literature', 91),
  (3, 'Linguistics',          85);

INSERT INTO payments (student_id, amount, mode, pay_date) VALUES
  (1, 20000, 'UPI',            '2026-06-15'),
  (3, 24000, 'Bank Transfer',  '2025-07-01');
