"""
Northfield Registrar — Backend API
====================================
Flask + MySQL REST API that mirrors the data model used by
student-management-system.html (students, attendance, marks, payments).

Run:
    pip install -r requirements.txt
    mysql -u root -p < schema.sql
    python app.py

The API listens on http://localhost:5000 by default.
CORS is enabled so the existing frontend (opened as a static file or
served separately) can call it directly with fetch().
"""

from datetime import date

import mysql.connector
from flask import Flask, jsonify, request
from flask_cors import CORS

from config import DB_CONFIG

app = Flask(__name__)
CORS(app)


def get_db():
    """Open a fresh connection for each request (simple + safe for a small app)."""
    return mysql.connector.connect(**DB_CONFIG)


def dict_cursor(conn):
    return conn.cursor(dictionary=True)


# ----------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------
def error(msg, code=400):
    return jsonify({"error": msg}), code


# ----------------------------------------------------------------------
# COURSES / FEE STRUCTURE
# ----------------------------------------------------------------------
@app.get("/api/courses")
def list_courses():
    conn = get_db()
    cur = dict_cursor(conn)
    cur.execute("SELECT course_name, annual_fee FROM courses ORDER BY course_name")
    rows = cur.fetchall()
    cur.close()
    conn.close()
    return jsonify(rows)


# ----------------------------------------------------------------------
# STUDENTS
# ----------------------------------------------------------------------
@app.get("/api/students")
def list_students():
    conn = get_db()
    cur = dict_cursor(conn)
    cur.execute("SELECT * FROM students ORDER BY admitted DESC")
    rows = cur.fetchall()
    cur.close()
    conn.close()
    return jsonify(rows)


@app.post("/api/students")
def create_student():
    data = request.get_json(force=True)
    required = ["name", "roll", "contact", "course", "year", "admitted"]
    missing = [f for f in required if not data.get(f)]
    if missing:
        return error(f"Missing fields: {', '.join(missing)}")

    conn = get_db()
    cur = conn.cursor()
    try:
        cur.execute(
            """INSERT INTO students (name, roll, contact, course, year, admitted)
               VALUES (%s, %s, %s, %s, %s, %s)""",
            (data["name"], data["roll"], data["contact"], data["course"],
             data["year"], data["admitted"]),
        )
        conn.commit()
        new_id = cur.lastrowid
    except mysql.connector.IntegrityError as e:
        conn.rollback()
        return error(f"Could not enroll student: {e}", 409)
    finally:
        cur.close()
        conn.close()

    return jsonify({"id": new_id, **data}), 201


@app.get("/api/students/<int:student_id>")
def get_student(student_id):
    conn = get_db()
    cur = dict_cursor(conn)
    cur.execute("SELECT * FROM students WHERE id = %s", (student_id,))
    row = cur.fetchone()
    cur.close()
    conn.close()
    if not row:
        return error("Student not found", 404)
    return jsonify(row)


# ----------------------------------------------------------------------
# ATTENDANCE
# ----------------------------------------------------------------------
@app.get("/api/attendance")
def list_attendance():
    student_id = request.args.get("student_id")
    conn = get_db()
    cur = dict_cursor(conn)
    if student_id:
        cur.execute(
            "SELECT * FROM attendance WHERE student_id = %s ORDER BY att_date DESC",
            (student_id,),
        )
    else:
        cur.execute("SELECT * FROM attendance ORDER BY att_date DESC")
    rows = cur.fetchall()
    cur.close()
    conn.close()
    return jsonify(rows)


@app.post("/api/attendance")
def mark_attendance():
    data = request.get_json(force=True)
    student_id = data.get("student_id")
    att_date = data.get("date")
    status = data.get("status")

    if not student_id or not att_date or status not in ("present", "absent"):
        return error("student_id, date, and status ('present'/'absent') are required")

    conn = get_db()
    cur = conn.cursor()
    # Upsert: same student + date overwrites the previous status, matching
    # the frontend's markAttendance() behaviour.
    cur.execute(
        """INSERT INTO attendance (student_id, att_date, status)
           VALUES (%s, %s, %s)
           ON DUPLICATE KEY UPDATE status = VALUES(status)""",
        (student_id, att_date, status),
    )
    conn.commit()
    cur.close()
    conn.close()
    return jsonify({"student_id": student_id, "date": att_date, "status": status}), 200


@app.get("/api/attendance/summary")
def attendance_summary():
    """Per-student attendance percentage, used for the Attendance tab table."""
    conn = get_db()
    cur = dict_cursor(conn)
    cur.execute(
        """
        SELECT s.id AS student_id, s.name, s.course,
               COUNT(a.id) AS total_marked,
               SUM(CASE WHEN a.status = 'present' THEN 1 ELSE 0 END) AS total_present
        FROM students s
        LEFT JOIN attendance a ON a.student_id = s.id
        GROUP BY s.id, s.name, s.course
        """
    )
    rows = cur.fetchall()
    cur.close()
    conn.close()

    for r in rows:
        if r["total_marked"]:
            r["percentage"] = round((r["total_present"] / r["total_marked"]) * 100)
        else:
            r["percentage"] = None
    return jsonify(rows)


# ----------------------------------------------------------------------
# MARKS
# ----------------------------------------------------------------------
@app.get("/api/marks")
def list_marks():
    student_id = request.args.get("student_id")
    conn = get_db()
    cur = dict_cursor(conn)
    if student_id:
        cur.execute("SELECT * FROM marks WHERE student_id = %s", (student_id,))
    else:
        cur.execute("SELECT * FROM marks")
    rows = cur.fetchall()
    cur.close()
    conn.close()
    return jsonify(rows)


@app.post("/api/marks")
def add_mark():
    data = request.get_json(force=True)
    student_id = data.get("student_id")
    subject = (data.get("subject") or "").strip()
    score = data.get("score")

    if not student_id or not subject or score is None:
        return error("student_id, subject, and score are required")
    try:
        score = max(0, min(100, float(score)))
    except (TypeError, ValueError):
        return error("score must be a number")

    conn = get_db()
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO marks (student_id, subject, score) VALUES (%s, %s, %s)",
        (student_id, subject, score),
    )
    conn.commit()
    new_id = cur.lastrowid
    cur.close()
    conn.close()
    return jsonify({"id": new_id, "student_id": student_id, "subject": subject, "score": score}), 201


@app.get("/api/marks/class-averages")
def class_averages():
    conn = get_db()
    cur = dict_cursor(conn)
    cur.execute(
        """
        SELECT s.course, COUNT(m.id) AS entries, AVG(m.score) AS average
        FROM marks m
        JOIN students s ON s.id = m.student_id
        GROUP BY s.course
        """
    )
    rows = cur.fetchall()
    cur.close()
    conn.close()
    for r in rows:
        r["average"] = round(float(r["average"]), 1) if r["average"] is not None else None
    return jsonify(rows)


# ----------------------------------------------------------------------
# PAYMENTS / FEES
# ----------------------------------------------------------------------
@app.get("/api/payments")
def list_payments():
    student_id = request.args.get("student_id")
    conn = get_db()
    cur = dict_cursor(conn)
    if student_id:
        cur.execute("SELECT * FROM payments WHERE student_id = %s ORDER BY pay_date DESC", (student_id,))
    else:
        cur.execute("SELECT * FROM payments ORDER BY pay_date DESC")
    rows = cur.fetchall()
    cur.close()
    conn.close()
    return jsonify(rows)


@app.post("/api/payments")
def record_payment():
    data = request.get_json(force=True)
    student_id = data.get("student_id")
    amount = data.get("amount")
    mode = data.get("mode")
    pay_date = data.get("date")

    if not student_id or amount is None or not mode or not pay_date:
        return error("student_id, amount, mode, and date are required")
    try:
        amount = float(amount)
        if amount <= 0:
            raise ValueError
    except (TypeError, ValueError):
        return error("amount must be a positive number")

    conn = get_db()
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO payments (student_id, amount, mode, pay_date) VALUES (%s, %s, %s, %s)",
        (student_id, amount, mode, pay_date),
    )
    conn.commit()
    new_id = cur.lastrowid
    cur.close()
    conn.close()
    return jsonify({"id": new_id, "student_id": student_id, "amount": amount,
                     "mode": mode, "date": pay_date}), 201


@app.get("/api/fees/ledger")
def fee_ledger():
    """Fee, paid, balance, and status per student — powers the Fees tab table."""
    conn = get_db()
    cur = dict_cursor(conn)
    cur.execute(
        """
        SELECT s.id AS student_id, s.name, s.course, c.annual_fee AS fee,
               COALESCE(SUM(p.amount), 0) AS paid
        FROM students s
        JOIN courses c ON c.course_name = s.course
        LEFT JOIN payments p ON p.student_id = s.id
        GROUP BY s.id, s.name, s.course, c.annual_fee
        """
    )
    rows = cur.fetchall()
    cur.close()
    conn.close()
    for r in rows:
        r["fee"] = float(r["fee"])
        r["paid"] = float(r["paid"])
        r["balance"] = max(r["fee"] - r["paid"], 0)
        r["status"] = "Paid" if r["fee"] - r["paid"] <= 0 else "Due"
    return jsonify(rows)


# ----------------------------------------------------------------------
# DASHBOARD
# ----------------------------------------------------------------------
@app.get("/api/dashboard")
def dashboard():
    conn = get_db()
    cur = dict_cursor(conn)

    cur.execute("SELECT COUNT(*) AS n FROM students")
    total_students = cur.fetchone()["n"]

    cur.execute(
        "SELECT COUNT(*) AS marked, SUM(status='present') AS present FROM attendance"
    )
    att = cur.fetchone()
    total_marked = att["marked"] or 0
    total_present = att["present"] or 0
    avg_attendance = round((total_present / total_marked) * 100) if total_marked else 0

    cur.execute("SELECT COUNT(*) AS n, COALESCE(SUM(amount),0) AS total FROM payments")
    pay = cur.fetchone()
    total_collected = float(pay["total"])
    payment_count = pay["n"]

    cur.execute(
        """
        SELECT s.id, c.annual_fee, COALESCE(SUM(p.amount),0) AS paid
        FROM students s
        JOIN courses c ON c.course_name = s.course
        LEFT JOIN payments p ON p.student_id = s.id
        GROUP BY s.id, c.annual_fee
        """
    )
    total_due = sum(max(float(r["annual_fee"]) - float(r["paid"]), 0) for r in cur.fetchall())

    cur.execute("SELECT name, admitted FROM students ORDER BY admitted DESC LIMIT 3")
    recent = cur.fetchall()

    cur.execute(
        """
        SELECT s.name, c.annual_fee - COALESCE(SUM(p.amount),0) AS due
        FROM students s
        JOIN courses c ON c.course_name = s.course
        LEFT JOIN payments p ON p.student_id = s.id
        GROUP BY s.id, s.name, c.annual_fee
        HAVING due > 0
        ORDER BY due DESC
        LIMIT 4
        """
    )
    top_dues = cur.fetchall()

    cur.close()
    conn.close()

    return jsonify({
        "total_students": total_students,
        "avg_attendance_pct": avg_attendance,
        "attendance_records": total_marked,
        "fees_collected": total_collected,
        "payment_count": payment_count,
        "fees_outstanding": total_due,
        "recent_admissions": [{"name": r["name"], "admitted": str(r["admitted"])} for r in recent],
        "top_dues": [{"name": r["name"], "due": float(r["due"])} for r in top_dues],
    })


# ----------------------------------------------------------------------
@app.get("/api/health")
def health():
    return jsonify({"status": "ok", "date": str(date.today())})


if __name__ == "__main__":
    app.run(debug=True, port=5000)
