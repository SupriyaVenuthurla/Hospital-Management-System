# Northfield Registrar — Backend

A Python (Flask) + MySQL backend that mirrors the data model already used
by `student-management-system.html` (students, attendance, marks, payments).
The original HTML file is untouched — this is an additive backend you can
wire the frontend up to whenever you're ready.

## Files

| File            | Purpose                                             |
|-----------------|------------------------------------------------------|
| `schema.sql`    | MySQL database, tables, and seed data (same demo data as the frontend) |
| `config.py`     | DB connection settings (reads from environment vars) |
| `app.py`        | Flask REST API                                       |
| `requirements.txt` | Python dependencies                               |

## 1. Set up MySQL

```bash
mysql -u root -p < schema.sql
```

This creates the `northfield_registrar` database with tables
`courses`, `students`, `attendance`, `marks`, `payments`, pre-loaded with
the same demo records the frontend starts with.

## 2. Install Python dependencies

```bash
cd backend
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## 3. Configure credentials (optional — defaults to root / no password)

```bash
export DB_HOST=localhost
export DB_PORT=3306
export DB_USER=root
export DB_PASSWORD=yourpassword
export DB_NAME=northfield_registrar
```

## 4. Run the API

```bash
python app.py
```

Server starts at `http://localhost:5000`.

## API Reference

| Method | Endpoint                     | Description                          |
|--------|-------------------------------|---------------------------------------|
| GET    | `/api/health`                 | Health check                          |
| GET    | `/api/courses`                | Course fee structure                  |
| GET    | `/api/students`                | List all students                     |
| POST   | `/api/students`                | Enroll a student                      |
| GET    | `/api/students/<id>`           | Get one student                       |
| GET    | `/api/attendance?student_id=`  | List attendance records               |
| POST   | `/api/attendance`              | Mark present/absent                   |
| GET    | `/api/attendance/summary`      | Per-student attendance %              |
| GET    | `/api/marks?student_id=`       | List marks                            |
| POST   | `/api/marks`                   | Add a mark                            |
| GET    | `/api/marks/class-averages`    | Average score by course               |
| GET    | `/api/payments?student_id=`    | List payments                         |
| POST   | `/api/payments`                | Record a payment                      |
| GET    | `/api/fees/ledger`             | Fee, paid, balance, status per student|
| GET    | `/api/dashboard`               | Aggregated dashboard stats            |

Example — enroll a student:

```bash
curl -X POST http://localhost:5000/api/students \
  -H "Content-Type: application/json" \
  -d '{"name":"Priya Nair","roll":"NF26-011","contact":"90000 11111","course":"B.Sc Computer Science","year":"1st Year","admitted":"2026-07-03"}'
```

## Connecting the existing frontend (when you're ready)

The HTML file currently keeps all data in-memory (`students`, `attendance`,
`marks`, `payments` arrays in its `<script>` block). To point it at this
API instead, you'd replace those arrays with `fetch()` calls to the
endpoints above — CORS is already enabled in `app.py` so the page can call
`http://localhost:5000/api/...` directly from the browser. Ask if you'd
like that wiring done as a next step.
