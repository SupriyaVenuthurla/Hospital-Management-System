"""
Database configuration for the Northfield Registrar backend.

All values can be overridden with environment variables, so you never
need to hard-code credentials in source control:

    export DB_HOST=localhost
    export DB_PORT=3306
    export DB_USER=root
    export DB_PASSWORD=yourpassword
    export DB_NAME=northfield_registrar
"""

import os

DB_CONFIG = {
    "host": os.environ.get("DB_HOST", "localhost"),
    "port": int(os.environ.get("DB_PORT", 3306)),
    "user": os.environ.get("DB_USER", "root"),
    "password": os.environ.get("DB_PASSWORD", ""),
    "database": os.environ.get("DB_NAME", "northfield_registrar"),
}
