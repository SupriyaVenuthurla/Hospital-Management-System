# Meridian Health — Hospital Management System (Full Stack)

This package adds a **Python (Flask) + MySQL backend** to the original
front-end you provided. The front-end (`frontend/`) is **byte-for-byte
unchanged** — same HTML, CSS, and JS files as the original upload.

```
hospital-management-system/
├── frontend/                  ← your original front-end, untouched
│   ├── index.html, doctors.html, appointments.html, patients.html,
│   │   dashboard.html, login.html, contact.html
│   ├── css/style.css
│   └── js/script.js
└── backend/                   ← new: Python + MySQL API
    ├── app.py                 Flask app (serves the API AND the front-end)
    ├── config.py               Configuration (reads .env)
    ├── db.py                   MySQL connection pool + query helpers
    ├── auth.py                 JWT helpers
    ├── routes/
    │   ├── auth_routes.py      POST /api/auth/login
    │   ├── doctors.py          GET /api/departments, /api/doctors
    │   ├── patients.py         GET /api/patients (staff only)
    │   ├── appointments.py     POST/GET /api/appointments
    │   ├── contact.py          POST/GET /api/contact
    │   └── dashboard.py        GET /api/dashboard/stats (staff only)
    ├── schema.sql              MySQL table definitions
    ├── seed.sql                Demo data (matches what was hard-coded in the HTML)
    ├── seed.py                 Creates demo login accounts (bcrypt-hashed)
    ├── requirements.txt
    └── .env.example
```

## Why the front-end wasn't touched

The original `js/script.js` runs entirely client-side and has no network
calls — it's a static demo (hard-coded doctor list, hard-coded patient
table, forms that just show a success message). Per your request, none of
that was modified. The backend below is a **fully working, independent
REST API** with a real MySQL database, built to match the exact data shown
in the front-end pages, so nothing here waits on front-end changes.

If/when you're ready to make the pages actually talk to this API (e.g.
have the login form call `/api/auth/login`, or have `patients.html` load
real rows via `fetch('/api/patients')`), the endpoints below are ready to
be wired in with a small amount of `fetch()` code — happy to do that in a
follow-up if you want it.

## 1. Install MySQL & Python dependencies

```bash
cd backend
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

Make sure a MySQL server is running and you know the root (or a
dedicated) user's credentials.

## 2. Configure environment

```bash
cp .env.example .env
# edit .env and set DB_USER / DB_PASSWORD / SECRET_KEY / JWT_SECRET_KEY
```

## 3. Create the database and load demo data

```bash
mysql -u root -p --default-character-set=utf8mb4 < schema.sql
mysql -u root -p --default-character-set=utf8mb4 < seed.sql
python seed.py     # creates demo login accounts (see below)
```

> **Important:** always pass `--default-character-set=utf8mb4` when
> loading the `.sql` files with the `mysql` CLI, otherwise names using
> special characters (e.g. "Cardiology · 3B") can get mangled.

Demo login accounts created by `seed.py`:

| Role    | Login ID  | Password    |
|---------|-----------|-------------|
| Patient | PT-10241  | patient123  |
| Staff   | DOC-0142  | staff123    |

## 4. Run the server

```bash
python app.py
```

By default this serves:
- the front-end at `http://localhost:5000/` (same pages, unchanged)
- the API at `http://localhost:5000/api/...`

## 5. API reference

| Method | Endpoint | Auth | Description |
|---|---|---|---|
| GET | `/api/health` | none | Health check |
| GET | `/api/departments` | none | List departments |
| GET | `/api/doctors?search=&department=` | none | Doctor directory (matches doctors.html filters) |
| GET | `/api/doctors/by-department/<code>` | none | For the appointment form's cascading doctor select |
| POST | `/api/auth/login` | none | `{loginId, password, role}` → `{token, role, displayName}` |
| POST | `/api/appointments` | none | Book an appointment (matches appointments.html form) |
| GET | `/api/appointments?date=` | staff | List appointments (for dashboard.html) |
| PATCH | `/api/appointments/<id>` | staff | Update status: pending/confirmed/cancelled |
| GET | `/api/patients?search=&status=` | staff | Patient records (matches patients.html filters) |
| GET | `/api/patients/<patient_code>` | staff | Single patient |
| POST | `/api/contact` | none | Submit a contact message |
| GET | `/api/contact` | staff | List contact messages |
| GET | `/api/dashboard/stats` | staff | KPI numbers for dashboard.html |

Staff-only endpoints require a header: `Authorization: Bearer <token>`
obtained from `/api/auth/login`.

## Notes on production use

- The dev server (`python app.py`) is for local development only. For
  production, run behind a WSGI server such as `gunicorn`:
  `gunicorn -w 4 -b 0.0.0.0:5000 app:app`
- Set real, random values for `SECRET_KEY` and `JWT_SECRET_KEY` in `.env`.
- Restrict `CORS_ORIGINS` to your real domain instead of `*` in production.
