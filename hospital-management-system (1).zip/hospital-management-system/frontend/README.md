# Meridian Health — Hospital Management System (Frontend)

A complete, static HTML/CSS/JS front-end for a hospital management system. No backend or build step required — just open the pages in a browser.

## Pages

- `index.html` — Homepage: hero, hospital stats, departments, booking process, CTA
- `doctors.html` — Doctor directory with live search + department filter
- `appointments.html` — Appointment booking form (department → doctor cascading select)
- `patients.html` — Patient records table with search + status filter
- `dashboard.html` — Staff dashboard: KPIs, upcoming appointments, admissions, department load
- `login.html` — Patient / Staff login with tab switcher
- `contact.html` — Contact form, visiting hours, emergency info

## Structure

```
hospital-management-system/
├── index.html
├── doctors.html
├── appointments.html
├── patients.html
├── dashboard.html
├── login.html
├── contact.html
├── css/
│   └── style.css
└── js/
    └── script.js
```

## How to run

Just open `index.html` in any modern browser. For the best experience (so relative links and fonts behave exactly as in a real deployment), you can also serve it locally:

```
# Python 3
python -m http.server 8000
# then visit http://localhost:8000
```

## Notes

- All forms are front-end only (no backend) — submitting shows an on-page success message and resets the form. Hook them up to your own backend/API when ready.
- The patient records and doctor directory are hard-coded demo data — swap in real data from a database or API by editing the HTML/JS.
- Fonts (Fraunces, IBM Plex Sans, IBM Plex Mono) load from Google Fonts via CDN; if you need a fully offline build, download the font files and update the `<link>` tags in each page's `<head>`.
- Design tokens (colors, type, spacing) are defined as CSS custom properties at the top of `css/style.css` — change them there to re-theme the whole site.
