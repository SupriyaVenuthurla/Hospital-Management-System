// ==========================================================================
// MERIDIAN HEALTH — shared interactivity (vanilla JS, no dependencies)
// ==========================================================================

document.addEventListener('DOMContentLoaded', function () {

  /* ---------- Mobile nav toggle ---------- */
  var toggle = document.querySelector('.nav-toggle');
  var links = document.querySelector('.nav-links');
  if (toggle && links) {
    toggle.addEventListener('click', function () {
      links.classList.toggle('open');
      toggle.setAttribute('aria-expanded', links.classList.contains('open'));
    });
  }

  /* ---------- Highlight active nav link ---------- */
  var here = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-links a').forEach(function (a) {
    var href = a.getAttribute('href');
    if (href === here) a.classList.add('active');
  });

  /* ---------- Login tabs ---------- */
  var tabBtns = document.querySelectorAll('.tab-btn');
  if (tabBtns.length) {
    tabBtns.forEach(function (btn) {
      btn.addEventListener('click', function () {
        tabBtns.forEach(function (b) { b.classList.remove('active'); });
        document.querySelectorAll('.tab-panel').forEach(function (p) { p.classList.remove('active'); });
        btn.classList.add('active');
        document.getElementById(btn.dataset.tab).classList.add('active');
      });
    });
  }

  /* ---------- Generic form "submit" handling (front-end only, no backend) ---------- */
  document.querySelectorAll('form[data-demo-form]').forEach(function (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!form.checkValidity()) { form.reportValidity(); return; }
      var successBox = form.querySelector('.form-success') || document.getElementById(form.dataset.successTarget || '');
      if (successBox) {
        successBox.classList.add('show');
        successBox.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }
      form.reset();
    });
  });

  /* ---------- Patients table: live search + status filter ---------- */
  var patientSearch = document.getElementById('patientSearch');
  var statusFilter = document.getElementById('statusFilter');
  var patientRows = document.querySelectorAll('#patientTable tbody tr');
  function filterPatients() {
    var q = (patientSearch && patientSearch.value || '').toLowerCase();
    var status = statusFilter && statusFilter.value;
    patientRows.forEach(function (row) {
      var text = row.textContent.toLowerCase();
      var matchesQuery = text.indexOf(q) !== -1;
      var matchesStatus = !status || status === 'all' || row.dataset.status === status;
      row.style.display = (matchesQuery && matchesStatus) ? '' : 'none';
    });
  }
  if (patientSearch) patientSearch.addEventListener('input', filterPatients);
  if (statusFilter) statusFilter.addEventListener('change', filterPatients);

  /* ---------- Doctors directory: search + department filter ---------- */
  var docSearch = document.getElementById('doctorSearch');
  var deptFilter = document.getElementById('departmentFilter');
  var doctorCards = document.querySelectorAll('.doctor-card');
  function filterDoctors() {
    var q = (docSearch && docSearch.value || '').toLowerCase();
    var dept = deptFilter && deptFilter.value;
    doctorCards.forEach(function (card) {
      var text = card.textContent.toLowerCase();
      var matchesQuery = text.indexOf(q) !== -1;
      var matchesDept = !dept || dept === 'all' || card.dataset.department === dept;
      card.style.display = (matchesQuery && matchesDept) ? '' : 'none';
    });
  }
  if (docSearch) docSearch.addEventListener('input', filterDoctors);
  if (deptFilter) deptFilter.addEventListener('change', filterDoctors);

  /* ---------- Appointment form: populate doctor list based on department ---------- */
  var deptSelect = document.getElementById('apptDepartment');
  var doctorSelect = document.getElementById('apptDoctor');
  var doctorsByDept = {
    cardiology: ['Dr. Meera Nair', 'Dr. Alan Cho'],
    neurology: ['Dr. Priya Sharma', 'Dr. Owen Blake'],
    orthopedics: ['Dr. Ravi Kumar', 'Dr. Sofia Martins'],
    pediatrics: ['Dr. Lily Zhang', 'Dr. Jason Reid'],
    dermatology: ['Dr. Anjali Rao', 'Dr. Ben Foster'],
    general: ['Dr. Tom Alexander', 'Dr. Grace Osei']
  };
  if (deptSelect && doctorSelect) {
    deptSelect.addEventListener('change', function () {
      var list = doctorsByDept[deptSelect.value] || [];
      doctorSelect.innerHTML = '<option value="">Select a doctor</option>' +
        list.map(function (name) { return '<option value="' + name + '">' + name + '</option>'; }).join('');
    });
  }

});
