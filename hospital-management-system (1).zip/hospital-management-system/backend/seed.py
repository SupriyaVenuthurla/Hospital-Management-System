"""
Creates demo login accounts for the Patient / Staff tabs on login.html.

Run AFTER schema.sql and seed.sql have been applied:
    python seed.py

Demo credentials created:
    Patient  ->  login: PT-10241   password: patient123
    Staff    ->  login: DOC-0142   password: staff123     (Dr. Meera Nair)
"""

import os

import bcrypt
import mysql.connector
from dotenv import load_dotenv

load_dotenv()


def get_connection():
    return mysql.connector.connect(
        host=os.getenv("DB_HOST", "localhost"),
        port=int(os.getenv("DB_PORT", "3306")),
        user=os.getenv("DB_USER", "root"),
        password=os.getenv("DB_PASSWORD", ""),
        database=os.getenv("DB_NAME", "meridian_health"),
        charset="utf8mb4",
        collation="utf8mb4_unicode_ci",
    )


def hash_password(plain: str) -> str:
    return bcrypt.hashpw(plain.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def main():
    conn = get_connection()
    cur = conn.cursor(dictionary=True)

    # Look up the demo patient + doctor created by seed.sql
    cur.execute("SELECT id FROM patients WHERE patient_code = %s", ("PT-10241",))
    patient = cur.fetchone()

    cur.execute("SELECT id FROM doctors WHERE name = %s", ("Dr. Meera Nair",))
    doctor = cur.fetchone()

    demo_users = []
    if patient:
        demo_users.append({
            "login_id": "PT-10241",
            "password": "patient123",
            "role": "patient",
            "display_name": "Arjun Whitfield",
            "patient_id": patient["id"],
            "doctor_id": None,
        })
    if doctor:
        demo_users.append({
            "login_id": "DOC-0142",
            "password": "staff123",
            "role": "staff",
            "display_name": "Dr. Meera Nair",
            "patient_id": None,
            "doctor_id": doctor["id"],
        })

    for u in demo_users:
        cur.execute("SELECT id FROM users WHERE login_id = %s", (u["login_id"],))
        if cur.fetchone():
            print(f"Skipping {u['login_id']} — already exists")
            continue
        cur.execute(
            """
            INSERT INTO users (login_id, password_hash, role, display_name, patient_id, doctor_id)
            VALUES (%s, %s, %s, %s, %s, %s)
            """,
            (
                u["login_id"],
                hash_password(u["password"]),
                u["role"],
                u["display_name"],
                u["patient_id"],
                u["doctor_id"],
            ),
        )
        print(f"Created {u['role']} login: {u['login_id']} / {u['password']}")

    conn.commit()
    cur.close()
    conn.close()
    print("Done.")


if __name__ == "__main__":
    main()
