"""
Small JWT helpers shared by every route module.
"""

import datetime
from functools import wraps

import jwt
from flask import current_app, request, jsonify


def make_token(payload: dict) -> str:
    to_encode = payload.copy()
    to_encode["exp"] = datetime.datetime.utcnow() + datetime.timedelta(
        minutes=current_app.config["JWT_ACCESS_TOKEN_EXPIRES_MINUTES"]
    )
    return jwt.encode(to_encode, current_app.config["JWT_SECRET_KEY"], algorithm="HS256")


def decode_token(token: str) -> dict:
    return jwt.decode(token, current_app.config["JWT_SECRET_KEY"], algorithms=["HS256"])


def _extract_token():
    auth = request.headers.get("Authorization", "")
    if auth.startswith("Bearer "):
        return auth.split(" ", 1)[1]
    return None


def login_required(role: str = None):
    """
    Decorator that requires a valid JWT. If `role` is given ('staff' or
    'patient'), the token's role claim must match, otherwise 403.
    Sets `request.user` to the decoded token payload.
    """

    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            token = _extract_token()
            if not token:
                return jsonify({"error": "Missing bearer token"}), 401
            try:
                payload = decode_token(token)
            except jwt.ExpiredSignatureError:
                return jsonify({"error": "Token expired"}), 401
            except jwt.InvalidTokenError:
                return jsonify({"error": "Invalid token"}), 401

            if role and payload.get("role") != role:
                return jsonify({"error": "Forbidden: requires role '%s'" % role}), 403

            request.user = payload
            return fn(*args, **kwargs)

        return wrapper

    return decorator
