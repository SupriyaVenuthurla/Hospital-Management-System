"""
GET /api/patients?search=...&status=admitted     (staff only)
GET /api/patients/<id>                            (staff only)
"""

from flask import Blueprint, request, jsonify

from db import query_all, query_one
from auth import login_required

bp = Blueprint("patients", __name__, url_prefix="/api/patients")


@bp.get("")
@login_required(role="staff")
def list_patients():
    search = (request.args.get("search") or "").strip()
    status = (request.args.get("status") or "").strip()

    sql = """
        SELECT p.id, p.patient_code, p.name, p.age, p.gender, p.status,
               p.ward, p.last_visit,
               dept.name AS department_name,
               doc.name  AS attending_doctor
        FROM patients p
        LEFT JOIN departments dept ON dept.id = p.department_id
        LEFT JOIN doctors doc      ON doc.id = p.attending_doctor_id
        WHERE 1=1
    """
    params = []

    if status and status != "all":
        sql += " AND p.status = %s"
        params.append(status)

    if search:
        sql += " AND (p.name LIKE %s OR p.patient_code LIKE %s)"
        like = f"%{search}%"
        params.extend([like, like])

    sql += " ORDER BY p.last_visit DESC"

    rows = query_all(sql, params)
    for r in rows:
        if r.get("last_visit"):
            r["last_visit"] = r["last_visit"].isoformat()
    return jsonify(rows)


@bp.get("/<patient_code>")
@login_required(role="staff")
def get_patient(patient_code):
    row = query_one(
        """
        SELECT p.id, p.patient_code, p.name, p.age, p.gender, p.status,
               p.ward, p.last_visit,
               dept.name AS department_name,
               doc.name  AS attending_doctor
        FROM patients p
        LEFT JOIN departments dept ON dept.id = p.department_id
        LEFT JOIN doctors doc      ON doc.id = p.attending_doctor_id
        WHERE p.patient_code = %s
        """,
        (patient_code,),
    )
    if not row:
        return jsonify({"error": "Patient not found"}), 404
    if row.get("last_visit"):
        row["last_visit"] = row["last_visit"].isoformat()
    return jsonify(row)
