"""
Auth endpoints — mirrors the two tabs on login.html (Patient / Staff).

POST /api/auth/login
    body: { "loginId": "PT-10241", "password": "...", "role": "patient" }
    body: { "loginId": "DOC-0142",  "password": "...", "role": "staff" }
    -> { "token": "...", "role": "...", "displayName": "..." }
"""

from flask import Blueprint, request, jsonify
import bcrypt

from db import query_one
from auth import make_token

bp = Blueprint("auth_routes", __name__, url_prefix="/api/auth")


@bp.post("/login")
def login():
    data = request.get_json(silent=True) or {}
    login_id = (data.get("loginId") or "").strip()
    password = data.get("password") or ""
    role = data.get("role")

    if not login_id or not password or role not in ("patient", "staff"):
        return jsonify({"error": "loginId, password and role ('patient'|'staff') are required"}), 400

    user = query_one(
        "SELECT * FROM users WHERE login_id = %s AND role = %s",
        (login_id, role),
    )
    if not user or not bcrypt.checkpw(password.encode("utf-8"), user["password_hash"].encode("utf-8")):
        return jsonify({"error": "Invalid credentials"}), 401

    token = make_token({
        "sub": user["id"],
        "role": user["role"],
        "loginId": user["login_id"],
        "patientId": user["patient_id"],
        "doctorId": user["doctor_id"],
    })

    return jsonify({
        "token": token,
        "role": user["role"],
        "displayName": user["display_name"],
    })
