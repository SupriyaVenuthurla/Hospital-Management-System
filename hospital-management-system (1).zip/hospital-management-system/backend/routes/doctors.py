"""
GET /api/departments
GET /api/doctors?search=...&department=cardiology
"""

from flask import Blueprint, request, jsonify

from db import query_all

bp = Blueprint("doctors", __name__, url_prefix="/api")


@bp.get("/departments")
def list_departments():
    rows = query_all("SELECT id, code, name FROM departments ORDER BY name")
    return jsonify(rows)


@bp.get("/doctors")
def list_doctors():
    search = (request.args.get("search") or "").strip()
    department = (request.args.get("department") or "").strip()

    sql = """
        SELECT d.id, d.name, d.role_title, d.experience_years, d.status,
               d.avatar_initials, d.tags, dept.code AS department_code,
               dept.name AS department_name
        FROM doctors d
        JOIN departments dept ON dept.id = d.department_id
        WHERE 1=1
    """
    params = []

    if department and department != "all":
        sql += " AND dept.code = %s"
        params.append(department)

    if search:
        sql += " AND (d.name LIKE %s OR d.role_title LIKE %s OR d.tags LIKE %s)"
        like = f"%{search}%"
        params.extend([like, like, like])

    sql += " ORDER BY d.name"

    rows = query_all(sql, params)
    for r in rows:
        r["tags"] = r["tags"].split(",") if r["tags"] else []
    return jsonify(rows)


@bp.get("/doctors/by-department/<department_code>")
def doctors_by_department(department_code):
    """Used to populate the cascading doctor <select> on appointments.html."""
    rows = query_all(
        """
        SELECT d.id, d.name
        FROM doctors d
        JOIN departments dept ON dept.id = d.department_id
        WHERE dept.code = %s
        ORDER BY d.name
        """,
        (department_code,),
    )
    return jsonify(rows)
