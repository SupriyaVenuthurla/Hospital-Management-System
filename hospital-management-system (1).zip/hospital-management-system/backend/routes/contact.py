"""
POST /api/contact   (public — the "Send a message" form on contact.html)
GET  /api/contact    (staff only — dashboard "Messages" list)
"""

from flask import Blueprint, request, jsonify

from db import execute, query_all
from auth import login_required

bp = Blueprint("contact", __name__, url_prefix="/api/contact")

REQUIRED_FIELDS = ["name", "email", "subject", "message"]


@bp.post("")
def send_message():
    data = request.get_json(silent=True) or {}
    missing = [f for f in REQUIRED_FIELDS if not data.get(f)]
    if missing:
        return jsonify({"error": f"Missing required field(s): {', '.join(missing)}"}), 400

    new_id, _ = execute(
        "INSERT INTO contact_messages (name, email, subject, message) VALUES (%s, %s, %s, %s)",
        (data["name"], data["email"], data["subject"], data["message"]),
    )
    return jsonify({
        "id": new_id,
        "message": "Message sent. We typically reply within one business day.",
    }), 201


@bp.get("")
@login_required(role="staff")
def list_messages():
    rows = query_all(
        "SELECT id, name, email, subject, message, created_at FROM contact_messages ORDER BY created_at DESC"
    )
    for r in rows:
        r["created_at"] = r["created_at"].isoformat()
    return jsonify(rows)
