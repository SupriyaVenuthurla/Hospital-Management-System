"""
GET /api/dashboard/stats   (staff only — feeds the KPI cards on dashboard.html)
"""

from flask import Blueprint, jsonify

from db import query_one, query_all
from auth import login_required

bp = Blueprint("dashboard", __name__, url_prefix="/api/dashboard")


@bp.get("/stats")
@login_required(role="staff")
def stats():
    todays_appts = query_one(
        "SELECT COUNT(*) AS c FROM appointments WHERE appt_date = CURDATE()"
    )["c"]

    admitted = query_one(
        "SELECT COUNT(*) AS c FROM patients WHERE status = 'admitted'"
    )["c"]

    new_admissions_today = query_one(
        "SELECT COUNT(*) AS c FROM patients WHERE status = 'admitted' AND last_visit = CURDATE()"
    )["c"]

    dept_load = query_all(
        """
        SELECT dept.name AS department, COUNT(p.id) AS patient_count
        FROM departments dept
        LEFT JOIN patients p ON p.department_id = dept.id AND p.status = 'admitted'
        GROUP BY dept.id, dept.name
        ORDER BY dept.name
        """
    )

    return jsonify({
        "todaysAppointments": todays_appts,
        "bedsOccupied": admitted,
        "newAdmissionsToday": new_admissions_today,
        "departmentLoad": dept_load,
    })
