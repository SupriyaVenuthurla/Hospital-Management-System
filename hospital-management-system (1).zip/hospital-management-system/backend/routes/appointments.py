"""
POST /api/appointments          (public — the booking form on appointments.html)
GET  /api/appointments          (staff only — used by dashboard.html)
PATCH /api/appointments/<id>    (staff only — confirm/cancel)
"""

import datetime

from flask import Blueprint, request, jsonify

from db import query_all, query_one, execute
from auth import login_required

bp = Blueprint("appointments", __name__, url_prefix="/api/appointments")

REQUIRED_FIELDS = ["fullName", "phone", "department", "doctorId", "date", "time"]


@bp.post("")
def book_appointment():
    data = request.get_json(silent=True) or {}
    missing = [f for f in REQUIRED_FIELDS if not data.get(f)]
    if missing:
        return jsonify({"error": f"Missing required field(s): {', '.join(missing)}"}), 400

    dept = query_one("SELECT id FROM departments WHERE code = %s", (data["department"],))
    if not dept:
        return jsonify({"error": "Unknown department"}), 400

    doctor = query_one(
        "SELECT id FROM doctors WHERE id = %s AND department_id = %s",
        (data["doctorId"], dept["id"]),
    )
    if not doctor:
        return jsonify({"error": "Doctor does not belong to the selected department"}), 400

    try:
        datetime.date.fromisoformat(data["date"])
        datetime.time.fromisoformat(data["time"])
    except ValueError:
        return jsonify({"error": "date must be YYYY-MM-DD and time must be HH:MM"}), 400

    new_id, _ = execute(
        """
        INSERT INTO appointments
            (full_name, phone, department_id, doctor_id, appt_date, appt_time, reason, status)
        VALUES (%s, %s, %s, %s, %s, %s, %s, 'pending')
        """,
        (
            data["fullName"],
            data["phone"],
            dept["id"],
            data["doctorId"],
            data["date"],
            data["time"],
            data.get("reason", ""),
        ),
    )

    return jsonify({
        "id": new_id,
        "status": "pending",
        "message": "Appointment requested. A confirmation with your doctor, room, and time will follow.",
    }), 201


@bp.get("")
@login_required(role="staff")
def list_appointments():
    date_filter = request.args.get("date")  # optional YYYY-MM-DD
    sql = """
        SELECT a.id, a.full_name, a.phone, a.appt_date, a.appt_time,
               a.reason, a.status, dept.name AS department_name, doc.name AS doctor_name
        FROM appointments a
        JOIN departments dept ON dept.id = a.department_id
        JOIN doctors doc      ON doc.id = a.doctor_id
        WHERE 1=1
    """
    params = []
    if date_filter:
        sql += " AND a.appt_date = %s"
        params.append(date_filter)
    sql += " ORDER BY a.appt_date, a.appt_time"

    rows = query_all(sql, params)
    for r in rows:
        r["appt_date"] = r["appt_date"].isoformat()
        r["appt_time"] = str(r["appt_time"])
    return jsonify(rows)


@bp.patch("/<int:appointment_id>")
@login_required(role="staff")
def update_appointment(appointment_id):
    data = request.get_json(silent=True) or {}
    status = data.get("status")
    if status not in ("pending", "confirmed", "cancelled"):
        return jsonify({"error": "status must be one of pending|confirmed|cancelled"}), 400

    _, row_count = execute(
        "UPDATE appointments SET status = %s WHERE id = %s", (status, appointment_id)
    )
    if row_count == 0:
        return jsonify({"error": "Appointment not found"}), 404
    return jsonify({"id": appointment_id, "status": status})
