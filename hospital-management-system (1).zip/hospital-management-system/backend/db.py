"""
MySQL connection pool + small query helpers.

Uses mysql-connector-python's built-in pooling so each request grabs a
connection from the pool instead of opening a brand-new TCP connection.
"""

import mysql.connector
from mysql.connector import pooling
from flask import current_app, g

_pool = None


def init_pool(app):
    """Create the connection pool once, at app start-up."""
    global _pool
    cfg = app.config
    _pool = pooling.MySQLConnectionPool(
        pool_name="meridian_pool",
        pool_size=10,
        pool_reset_session=True,
        host=cfg["DB_HOST"],
        port=cfg["DB_PORT"],
        user=cfg["DB_USER"],
        password=cfg["DB_PASSWORD"],
        database=cfg["DB_NAME"],
        autocommit=False,
        charset="utf8mb4",
        collation="utf8mb4_unicode_ci",
    )


def get_conn():
    """Return a pooled connection for the current request (auto-closed after)."""
    if "db_conn" not in g:
        g.db_conn = _pool.get_connection()
    return g.db_conn


def close_conn(e=None):
    conn = g.pop("db_conn", None)
    if conn is not None:
        conn.close()


def query_all(sql, params=None):
    """SELECT returning a list of dict rows."""
    conn = get_conn()
    cur = conn.cursor(dictionary=True)
    cur.execute(sql, params or ())
    rows = cur.fetchall()
    cur.close()
    return rows


def query_one(sql, params=None):
    """SELECT returning a single dict row or None."""
    conn = get_conn()
    cur = conn.cursor(dictionary=True)
    cur.execute(sql, params or ())
    row = cur.fetchone()
    cur.close()
    return row


def execute(sql, params=None):
    """INSERT/UPDATE/DELETE. Commits and returns (lastrowid, rowcount)."""
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(sql, params or ())
    conn.commit()
    last_id, row_count = cur.lastrowid, cur.rowcount
    cur.close()
    return last_id, row_count
