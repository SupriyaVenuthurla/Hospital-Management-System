"""
Meridian Health — Flask + MySQL backend.

Run:
    python app.py
Serves:
    - The unmodified static front-end (frontend/*.html, css/, js/) at "/"
    - JSON REST API under "/api/..."
"""

import os

from flask import Flask, send_from_directory, jsonify
from flask_cors import CORS
from dotenv import load_dotenv

load_dotenv()

from config import Config
import db as db_module

from routes.auth_routes import bp as auth_bp
from routes.doctors import bp as doctors_bp
from routes.patients import bp as patients_bp
from routes.appointments import bp as appointments_bp
from routes.contact import bp as contact_bp
from routes.dashboard import bp as dashboard_bp


def create_app():
    app = Flask(
        __name__,
        static_folder=Config.FRONTEND_DIR,
        static_url_path="",
    )
    app.config.from_object(Config)

    CORS(app, resources={r"/api/*": {"origins": Config.CORS_ORIGINS}})

    db_module.init_pool(app)
    app.teardown_appcontext(db_module.close_conn)

    app.register_blueprint(auth_bp)
    app.register_blueprint(doctors_bp)
    app.register_blueprint(patients_bp)
    app.register_blueprint(appointments_bp)
    app.register_blueprint(contact_bp)
    app.register_blueprint(dashboard_bp)

    # ---- Serve the untouched front-end -----------------------------------
    @app.route("/")
    def index():
        return send_from_directory(app.static_folder, "index.html")

    @app.route("/<path:path>")
    def static_files(path):
        full_path = os.path.join(app.static_folder, path)
        if os.path.isfile(full_path):
            return send_from_directory(app.static_folder, path)
        # Fallback for direct hits like /dashboard (no .html) -> dashboard.html
        html_path = f"{path}.html"
        if os.path.isfile(os.path.join(app.static_folder, html_path)):
            return send_from_directory(app.static_folder, html_path)
        return jsonify({"error": "Not found"}), 404

    # ---- Health check ------------------------------------------------------
    @app.route("/api/health")
    def health():
        return jsonify({"status": "ok"})

    # ---- Error handlers ------------------------------------------------------
    @app.errorhandler(404)
    def not_found(e):
        return jsonify({"error": "Not found"}), 404

    @app.errorhandler(500)
    def server_error(e):
        return jsonify({"error": "Internal server error"}), 500

    return app


app = create_app()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "5000")), debug=Config.DEBUG)
