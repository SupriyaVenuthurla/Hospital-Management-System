"""
Configuration for the Meridian Health backend.
All values are read from environment variables (see .env.example),
loaded via python-dotenv in app.py.
"""

import os


class Config:
    # --- MySQL connection ---------------------------------------------------
    DB_HOST = os.getenv("DB_HOST", "localhost")
    DB_PORT = int(os.getenv("DB_PORT", "3306"))
    DB_USER = os.getenv("DB_USER", "root")
    DB_PASSWORD = os.getenv("DB_PASSWORD", "")
    DB_NAME = os.getenv("DB_NAME", "meridian_health")

    # --- Flask / security -----------------------------------------------------
    SECRET_KEY = os.getenv("SECRET_KEY", "change-this-in-production")
    JWT_SECRET_KEY = os.getenv("JWT_SECRET_KEY", "change-this-jwt-secret-in-production")
    JWT_ACCESS_TOKEN_EXPIRES_MINUTES = int(os.getenv("JWT_ACCESS_TOKEN_EXPIRES_MINUTES", "480"))

    # --- CORS -----------------------------------------------------------------
    # Comma separated list of allowed origins, e.g. "http://localhost:8000,http://127.0.0.1:8000"
    CORS_ORIGINS = os.getenv("CORS_ORIGINS", "*")

    # --- Static frontend --------------------------------------------------------
    # Folder containing the untouched front-end (index.html, css/, js/, ...)
    FRONTEND_DIR = os.getenv(
        "FRONTEND_DIR",
        os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "frontend"),
    )

    DEBUG = os.getenv("FLASK_DEBUG", "0") == "1"
