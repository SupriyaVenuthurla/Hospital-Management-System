-- ============================================================================
-- Seed data — mirrors the demo data hard-coded in the front-end HTML/JS
-- Run AFTER schema.sql
-- ============================================================================

USE meridian_health;

-- ---------------------------------------------------------------------------
-- Departments
-- ---------------------------------------------------------------------------
INSERT INTO departments (code, name) VALUES
  ('cardiology',   'Cardiology'),
  ('neurology',    'Neurology'),
  ('orthopedics',  'Orthopedics'),
  ('pediatrics',   'Pediatrics'),
  ('dermatology',  'Dermatology'),
  ('general',      'General Medicine')
ON DUPLICATE KEY UPDATE name = VALUES(name);

-- ---------------------------------------------------------------------------
-- Doctors  (matches doctors.html + doctorsByDept map in script.js)
-- ---------------------------------------------------------------------------
INSERT INTO doctors (name, role_title, department_id, experience_years, status, avatar_initials, tags) VALUES
  ('Dr. Meera Nair',    'Senior Cardiologist',          (SELECT id FROM departments WHERE code='cardiology'),  14, 'available', 'MN', 'Cardiology,Echocardiography'),
  ('Dr. Alan Cho',      'Interventional Cardiologist',  (SELECT id FROM departments WHERE code='cardiology'),   9, 'busy',      'AC', 'Cardiology,Angioplasty'),
  ('Dr. Priya Sharma',  'Consultant Neurologist',       (SELECT id FROM departments WHERE code='neurology'),   17, 'available', 'PS', 'Neurology,Stroke care'),
  ('Dr. Owen Blake',    'Neurologist',                  (SELECT id FROM departments WHERE code='neurology'),    6, 'off',       'OB', 'Neurology,EEG diagnostics'),
  ('Dr. Ravi Kumar',    'Orthopedic Surgeon',           (SELECT id FROM departments WHERE code='orthopedics'), 21, 'available', 'RK', 'Orthopedics,Joint replacement'),
  ('Dr. Sofia Martins', 'Sports Medicine Specialist',   (SELECT id FROM departments WHERE code='orthopedics'),  8, 'busy',      'SM', 'Orthopedics,Physiotherapy'),
  ('Dr. Lily Zhang',    'Pediatrician',                 (SELECT id FROM departments WHERE code='pediatrics'),  11, 'available', 'LZ', 'Pediatrics,Vaccinations'),
  ('Dr. Jason Reid',    'Pediatrician',                 (SELECT id FROM departments WHERE code='pediatrics'),   7, 'available', 'JR', 'Pediatrics,Newborn care'),
  ('Dr. Anjali Rao',    'Dermatologist',                (SELECT id FROM departments WHERE code='dermatology'), 13, 'available', 'AR', 'Dermatology,Cosmetic consults'),
  ('Dr. Ben Foster',    'Dermatologist',                (SELECT id FROM departments WHERE code='dermatology'),  5, 'available', 'BF', 'Dermatology,Skin conditions'),
  ('Dr. Tom Alexander', 'General Physician',            (SELECT id FROM departments WHERE code='general'),     19, 'available', 'TA', 'General Medicine,Primary care'),
  ('Dr. Grace Osei',    'General Physician',            (SELECT id FROM departments WHERE code='general'),      10, 'available', 'GO', 'General Medicine,Screenings');

-- ---------------------------------------------------------------------------
-- Patients  (matches patients.html table rows)
-- ---------------------------------------------------------------------------
INSERT INTO patients (patient_code, name, age, gender, department_id, attending_doctor_id, status, ward, last_visit) VALUES
  ('PT-10241', 'Arjun Whitfield',   54, 'M', (SELECT id FROM departments WHERE code='cardiology'),  (SELECT id FROM doctors WHERE name='Dr. Meera Nair'),   'admitted',   'Cardiology · 3A',  '2026-07-03'),
  ('PT-10242', 'Sneha Patil',       29, 'F', (SELECT id FROM departments WHERE code='dermatology'),  (SELECT id FROM doctors WHERE name='Dr. Anjali Rao'),   'opd',        NULL,               '2026-07-02'),
  ('PT-10198', 'Rohan Mehta',       41, 'M', (SELECT id FROM departments WHERE code='orthopedics'),  (SELECT id FROM doctors WHERE name='Dr. Ravi Kumar'),   'discharged', NULL,               '2026-06-28'),
  ('PT-10250', 'Fatima Sheikh',      7, 'F', (SELECT id FROM departments WHERE code='pediatrics'),   (SELECT id FROM doctors WHERE name='Dr. Lily Zhang'),   'admitted',   'Pediatrics · 2A',  '2026-07-04'),
  ('PT-10233', 'David Kurian',      63, 'M', (SELECT id FROM departments WHERE code='neurology'),    (SELECT id FROM doctors WHERE name='Dr. Priya Sharma'), 'opd',        NULL,               '2026-07-01'),
  ('PT-10177', 'Lakshmi Iyer',      35, 'F', (SELECT id FROM departments WHERE code='general'),      (SELECT id FROM doctors WHERE name='Dr. Tom Alexander'),'discharged', NULL,               '2026-06-20'),
  ('PT-10255', 'Michael Fernandes', 48, 'M', (SELECT id FROM departments WHERE code='cardiology'),   (SELECT id FROM doctors WHERE name='Dr. Alan Cho'),     'admitted',   'Cardiology · 3B',  '2026-07-04'),
  ('PT-10261', 'Neha Verma',        26, 'F', (SELECT id FROM departments WHERE code='orthopedics'),  (SELECT id FROM doctors WHERE name='Dr. Sofia Martins'),'opd',        NULL,               '2026-07-03');

-- ---------------------------------------------------------------------------
-- Appointments  (matches "Upcoming appointments" panel on dashboard.html)
-- ---------------------------------------------------------------------------
INSERT INTO appointments (full_name, phone, department_id, doctor_id, appt_date, appt_time, reason, status) VALUES
  ('Arjun Whitfield',   '9800000001', (SELECT id FROM departments WHERE code='cardiology'), (SELECT id FROM doctors WHERE name='Dr. Meera Nair'),   CURDATE(), '09:30:00', 'Follow-up on cardiac monitoring', 'confirmed'),
  ('Sneha Patil',       '9800000002', (SELECT id FROM departments WHERE code='dermatology'), (SELECT id FROM doctors WHERE name='Dr. Anjali Rao'),   CURDATE(), '10:15:00', 'Skin consultation', 'confirmed'),
  ('David Kurian',      '9800000003', (SELECT id FROM departments WHERE code='neurology'),   (SELECT id FROM doctors WHERE name='Dr. Priya Sharma'), CURDATE(), '11:00:00', 'Stroke follow-up', 'pending'),
  ('Neha Verma',        '9800000004', (SELECT id FROM departments WHERE code='orthopedics'), (SELECT id FROM doctors WHERE name='Dr. Sofia Martins'),CURDATE(), '11:45:00', 'Physiotherapy review', 'confirmed'),
  ('Michael Fernandes', '9800000005', (SELECT id FROM departments WHERE code='cardiology'),  (SELECT id FROM doctors WHERE name='Dr. Alan Cho'),     CURDATE(), '13:30:00', 'Angioplasty follow-up', 'pending');

-- ---------------------------------------------------------------------------
-- NOTE: demo login users (patients/staff) are created by backend/seed.py
-- because their passwords must be bcrypt-hashed using the same library
-- the running application uses to verify them.
-- ---------------------------------------------------------------------------
