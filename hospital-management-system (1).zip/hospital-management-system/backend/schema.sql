-- ============================================================================
-- Meridian Health — Hospital Management System
-- MySQL schema
-- ============================================================================

CREATE DATABASE IF NOT EXISTS meridian_health
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE meridian_health;

-- ---------------------------------------------------------------------------
-- Departments
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS departments (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  code          VARCHAR(40)  NOT NULL UNIQUE,   -- e.g. 'cardiology'
  name          VARCHAR(100) NOT NULL           -- e.g. 'Cardiology'
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------------
-- Doctors
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS doctors (
  id                INT AUTO_INCREMENT PRIMARY KEY,
  name              VARCHAR(120) NOT NULL,          -- 'Dr. Meera Nair'
  role_title        VARCHAR(150) NOT NULL,           -- 'Senior Cardiologist'
  department_id     INT NOT NULL,
  experience_years   INT NOT NULL DEFAULT 0,
  status            ENUM('available','busy','off') NOT NULL DEFAULT 'available',
  avatar_initials   VARCHAR(5)  NOT NULL,
  tags              VARCHAR(255) NULL,               -- comma separated tag pills
  created_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------------
-- Patients
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS patients (
  id                  INT AUTO_INCREMENT PRIMARY KEY,
  patient_code        VARCHAR(20) NOT NULL UNIQUE,   -- 'PT-10241'
  name                VARCHAR(120) NOT NULL,
  age                 INT NOT NULL,
  gender              ENUM('M','F','O') NOT NULL,
  department_id       INT NULL,
  attending_doctor_id INT NULL,
  status              ENUM('admitted','opd','discharged') NOT NULL DEFAULT 'opd',
  ward                VARCHAR(60) NULL,
  last_visit          DATE NULL,
  created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL,
  FOREIGN KEY (attending_doctor_id) REFERENCES doctors(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------------
-- Appointments  (created from the "Book an appointment" form)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS appointments (
  id              INT AUTO_INCREMENT PRIMARY KEY,
  full_name       VARCHAR(120) NOT NULL,
  phone           VARCHAR(30)  NOT NULL,
  department_id   INT NOT NULL,
  doctor_id       INT NOT NULL,
  appt_date       DATE NOT NULL,
  appt_time       TIME NOT NULL,
  reason          TEXT NULL,
  status          ENUM('pending','confirmed','cancelled') NOT NULL DEFAULT 'pending',
  created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE RESTRICT,
  FOREIGN KEY (doctor_id) REFERENCES doctors(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------------
-- Contact messages (from the "Contact" page form)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS contact_messages (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(120) NOT NULL,
  email       VARCHAR(150) NOT NULL,
  subject     VARCHAR(120) NOT NULL,
  message     TEXT NOT NULL,
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------------
-- Users (login for both patient & staff tabs on login.html)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
  id              INT AUTO_INCREMENT PRIMARY KEY,
  login_id        VARCHAR(40) NOT NULL UNIQUE,   -- 'PT-10241' or 'DOC-0142'
  password_hash   VARCHAR(255) NOT NULL,
  role            ENUM('patient','staff') NOT NULL,
  display_name    VARCHAR(120) NOT NULL,
  patient_id      INT NULL,
  doctor_id       INT NULL,
  created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE SET NULL,
  FOREIGN KEY (doctor_id) REFERENCES doctors(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------------
-- Helpful indexes
-- ---------------------------------------------------------------------------
CREATE INDEX idx_patients_status ON patients(status);
CREATE INDEX idx_appointments_date ON appointments(appt_date);
CREATE INDEX idx_doctors_department ON doctors(department_id);
